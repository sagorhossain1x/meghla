package com.meghla.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val START = "file:///android_asset/start.html"
private const val DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

class MainActivity : AppCompatActivity() {

    private class Tab(val web: WebView) {
        var title = ""
        var url = ""
        var loading = false
    }

    private data class Entry(val title: String, val url: String)

    private val tabs = mutableListOf<Tab>()
    private var current: Tab? = null
    private var desktop = false
    private var bookmarks = mutableListOf<Entry>()
    private var history = mutableListOf<Entry>()

    private lateinit var prefs: SharedPreferences
    private lateinit var defaultUA: String
    private lateinit var content: FrameLayout
    private lateinit var omni: EditText
    private lateinit var progress: ProgressBar
    private lateinit var tabsBtn: TextView
    private lateinit var btnBack: TextView
    private lateinit var btnFwd: TextView
    private lateinit var btnReload: TextView
    private lateinit var btnStar: TextView

    private var night = false
    private var cBg = 0
    private var cOmni = 0
    private var cFg = 0
    private var cMuted = 0
    private var cAccent = 0
    private var cLine = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        cBg = Color.parseColor(if (night) "#1F252C" else "#FFFFFF")
        cOmni = Color.parseColor(if (night) "#11151A" else "#EEF1F4")
        cFg = Color.parseColor(if (night) "#E6EBF1" else "#1D2530")
        cMuted = Color.parseColor(if (night) "#98A3B1" else "#5D6877")
        cAccent = Color.parseColor(if (night) "#4CC3BB" else "#0B7A75")
        cLine = Color.parseColor(if (night) "#313A44" else "#CFD5DC")

        prefs = getSharedPreferences("meghla", MODE_PRIVATE)
        bookmarks = readList("bookmarks")
        history = readList("history")
        defaultUA = WebSettings.getDefaultUserAgent(this)

        setContentView(buildUi())
        window.statusBarColor = cBg
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = !night

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val t = current
                when {
                    t == null -> finish()
                    t.web.canGoBack() -> t.web.goBack()
                    tabs.size > 1 -> closeTab(t)
                    else -> finish()
                }
            }
        })

        newTab(intent?.data?.toString() ?: START)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.let { newTab(it.toString()) }
    }

    override fun onDestroy() {
        tabs.forEach { it.web.destroy() }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun iconButton(text: String, size: Float): TextView {
        val v = TextView(this)
        v.text = text
        v.textSize = size
        v.setTextColor(cFg)
        v.gravity = Gravity.CENTER
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        v.setBackgroundResource(tv.resourceId)
        return v
    }

    private fun buildUi(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(cBg)

        // top row: address bar, tab count, menu
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(8), dp(6), dp(4), dp(6))

        omni = EditText(this)
        omni.hint = "গুগলে সার্চ করুন বা ঠিকানা লিখুন"
        omni.setHintTextColor(cMuted)
        omni.setTextColor(cFg)
        omni.textSize = 15f
        omni.isSingleLine = true
        omni.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        omni.imeOptions = EditorInfo.IME_ACTION_GO
        omni.setSelectAllOnFocus(true)
        val omniBg = GradientDrawable()
        omniBg.cornerRadius = dp(22).toFloat()
        omniBg.setColor(cOmni)
        omni.background = omniBg
        omni.setPadding(dp(18), 0, dp(18), 0)
        omni.setOnEditorActionListener { _, actionId, event ->
            val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                loadInput(omni.text.toString())
                hideKeyboard()
                omni.clearFocus()
                true
            } else false
        }
        top.addView(omni, LinearLayout.LayoutParams(0, dp(44), 1f))

        tabsBtn = TextView(this)
        tabsBtn.text = "1"
        tabsBtn.textSize = 13f
        tabsBtn.typeface = Typeface.DEFAULT_BOLD
        tabsBtn.setTextColor(cFg)
        tabsBtn.gravity = Gravity.CENTER
        val box = GradientDrawable()
        box.cornerRadius = dp(6).toFloat()
        box.setStroke(dp(2), cFg)
        box.setColor(Color.TRANSPARENT)
        tabsBtn.background = box
        tabsBtn.setOnClickListener { showTabs() }
        val tl = LinearLayout.LayoutParams(dp(28), dp(28))
        tl.setMargins(dp(10), 0, dp(6), 0)
        top.addView(tabsBtn, tl)

        val menuBtn = iconButton("⋮", 24f)
        menuBtn.setOnClickListener { showMenu(it) }
        top.addView(menuBtn, LinearLayout.LayoutParams(dp(40), dp(44)))
        root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.progressTintList = ColorStateList.valueOf(cAccent)
        progress.visibility = View.INVISIBLE
        root.addView(progress, LinearLayout.LayoutParams(MATCH, dp(3)))

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val divider = View(this)
        divider.setBackgroundColor(cLine)
        root.addView(divider, LinearLayout.LayoutParams(MATCH, dp(1)))

        // bottom row: back, forward, reload, home, bookmark
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        btnBack = iconButton("←", 22f)
        btnFwd = iconButton("→", 22f)
        btnReload = iconButton("↻", 22f)
        val btnHome = iconButton("⌂", 22f)
        btnStar = iconButton("☆", 22f)
        btnBack.setOnClickListener { current?.web?.let { if (it.canGoBack()) it.goBack() } }
        btnFwd.setOnClickListener { current?.web?.let { if (it.canGoForward()) it.goForward() } }
        btnReload.setOnClickListener {
            current?.let { if (it.loading) it.web.stopLoading() else it.web.reload() }
        }
        btnHome.setOnClickListener { current?.web?.loadUrl(START) }
        btnStar.setOnClickListener { toggleBookmark() }
        for (b in listOf(btnBack, btnFwd, btnReload, btnHome, btnStar)) {
            bottom.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(bottom, LinearLayout.LayoutParams(MATCH, WRAP))
        return root
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(omni.windowToken, 0)
    }

    private fun isStart(url: String) = url.isEmpty() || url.startsWith(START)

    private fun updateUi() {
        val t = current ?: return
        if (!omni.hasFocus()) omni.setText(if (isStart(t.url)) "" else t.url)
        tabsBtn.text = tabs.size.toString()
        btnBack.alpha = if (t.web.canGoBack()) 1f else 0.35f
        btnFwd.alpha = if (t.web.canGoForward()) 1f else 0.35f
        btnReload.text = if (t.loading) "✕" else "↻"
        val marked = bookmarks.any { it.url == t.url }
        btnStar.text = if (marked) "★" else "☆"
        btnStar.setTextColor(if (marked) cAccent else cFg)
    }

    // ---------------------------------------------------------------- tabs

    private fun newTab(url: String?): Tab {
        val web = WebView(this)
        val tab = Tab(web)
        setupWebView(tab)
        tabs.add(tab)
        content.addView(web, FrameLayout.LayoutParams(MATCH, MATCH))
        switchTo(tab)
        if (url != null) web.loadUrl(url)
        return tab
    }

    private fun switchTo(tab: Tab) {
        for (t in tabs) t.web.visibility = if (t === tab) View.VISIBLE else View.GONE
        current = tab
        omni.clearFocus()
        progress.visibility = if (tab.loading) View.VISIBLE else View.INVISIBLE
        updateUi()
    }

    private fun closeTab(tab: Tab) {
        val i = tabs.indexOf(tab)
        if (i < 0) return
        val wasCurrent = tab === current
        content.removeView(tab.web)
        tab.web.destroy()
        tabs.removeAt(i)
        when {
            tabs.isEmpty() -> newTab(START)
            wasCurrent -> switchTo(tabs[minOf(i, tabs.size - 1)])
            else -> updateUi()
        }
    }

    private fun showTabs() {
        val names = tabs.map {
            val label = if (isStart(it.url)) "নতুন ট্যাব" else it.title.ifBlank { it.url }
            (if (it === current) "● " else "   ") + label
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("ট্যাব (${tabs.size})")
            .setItems(names) { _, i -> switchTo(tabs[i]) }
            .setPositiveButton("নতুন ট্যাব") { _, _ ->
                newTab(START)
            }
            .setNeutralButton("এই ট্যাব বন্ধ") { _, _ -> current?.let { closeTab(it) } }
            .setNegativeButton("বন্ধ", null)
            .show()
    }

    // ---------------------------------------------------------------- web view

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView(tab: Tab) {
        val web = tab.web
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = false
        }
        applyUserAgent(web)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.setDownloadListener { url, userAgent, disposition, mime, _ ->
            try {
                val req = DownloadManager.Request(Uri.parse(url))
                req.setMimeType(mime)
                req.addRequestHeader("User-Agent", userAgent)
                CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, disposition, mime)
                )
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                toast("ডাউনলোড শুরু হয়েছে")
            } catch (e: Exception) {
                toast("ডাউনলোড করা যায়নি")
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: ""
                if (scheme in listOf("http", "https", "file", "about", "data", "blob", "javascript")) {
                    return false
                }
                try {
                    val intent = if (scheme == "intent") {
                        Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                    } else {
                        Intent(Intent.ACTION_VIEW, uri)
                    }
                    startActivity(intent)
                } catch (e: ActivityNotFoundException) {
                    toast("এই লিংক খোলার অ্যাপ নেই")
                } catch (e: Exception) {
                    toast("লিংক খোলা যায়নি")
                }
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                tab.url = url
                tab.loading = true
                if (isStart(url)) tab.title = "নতুন ট্যাব"
                if (tab === current) {
                    progress.visibility = View.VISIBLE
                    updateUi()
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                tab.url = url
                tab.loading = false
                tab.title = view.title?.takeIf { it.isNotBlank() } ?: url
                addHistory(tab.title, url)
                if (tab === current) {
                    progress.visibility = View.INVISIBLE
                    updateUi()
                }
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                tab.url = url
                if (tab === current) updateUi()
            }

            override fun onReceivedError(
                view: WebView, request: WebResourceRequest, error: WebResourceError
            ) {
                if (!request.isForMainFrame) return
                val u = TextUtils.htmlEncode(request.url.toString())
                val why = TextUtils.htmlEncode(error.description.toString())
                val html = "<meta name='viewport' content='width=device-width,initial-scale=1'>" +
                    "<body style='font-family:sans-serif;padding:14vh 22px;color:#444'>" +
                    "<h2>পেজটি খোলা যায়নি</h2><p style='word-break:break-all'>$u</p>" +
                    "<p>ইন্টারনেট সংযোগ ও ঠিকানা ঠিক আছে কিনা দেখুন।<br><small>$why</small></p></body>"
                view.loadDataWithBaseURL(request.url.toString(), html, "text/html", "utf-8", request.url.toString())
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (tab === current) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress < 100) View.VISIBLE else View.INVISIBLE
                }
            }

            override fun onReceivedTitle(view: WebView, title: String) {
                if (title.isNotBlank()) tab.title = title
            }

            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message
            ): Boolean {
                val newOne = newTab(null)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = newOne.web
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                tabs.firstOrNull { it.web === window }?.let { closeTab(it) }
            }
        }
    }

    private fun applyUserAgent(web: WebView) {
        web.settings.userAgentString = if (desktop) DESKTOP_UA else defaultUA
    }

    private fun loadInput(text: String) {
        val s = text.trim()
        if (s.isEmpty()) return
        val url = when {
            Regex("^(https?|file)://.*", RegexOption.IGNORE_CASE).matches(s) -> s
            !s.contains(Regex("\\s")) &&
                Regex("^[^\\s/]+\\.[a-zA-Z]{2,}(:\\d+)?(/.*)?$").matches(s) -> "https://$s"
            Regex("^localhost(:\\d+)?(/.*)?$").matches(s) -> "http://$s"
            else -> "https://www.google.com/search?q=" + Uri.encode(s)
        }
        current?.web?.loadUrl(url)
    }

    // ---------------------------------------------------------------- menu, bookmarks, history

    private fun showMenu(anchor: View) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "নতুন ট্যাব")
        menu.menu.add(0, 2, 1, "বুকমার্ক")
        menu.menu.add(0, 3, 2, "ইতিহাস")
        menu.menu.add(0, 4, 3, "ডেস্কটপ সাইট: " + if (desktop) "চালু" else "বন্ধ")
        menu.menu.add(0, 5, 4, "শেয়ার করুন")
        menu.menu.add(0, 6, 5, "ইতিহাস মুছুন")
        menu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> newTab(START)
                2 -> showBookmarks()
                3 -> showHistory()
                4 -> {
                    desktop = !desktop
                    tabs.forEach { applyUserAgent(it.web) }
                    current?.web?.reload()
                    toast(if (desktop) "ডেস্কটপ সাইট চালু" else "মোবাইল সাইট চালু")
                }
                5 -> shareCurrent()
                6 -> {
                    history.clear()
                    writeList("history", history)
                    toast("ইতিহাস মুছে ফেলা হয়েছে")
                }
            }
            true
        }
        menu.show()
    }

    private fun shareCurrent() {
        val t = current ?: return
        if (isStart(t.url)) return
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, t.url)
        startActivity(Intent.createChooser(send, "শেয়ার করুন"))
    }

    private fun toggleBookmark() {
        val t = current ?: return
        if (isStart(t.url)) {
            toast("এই পেজ বুকমার্ক করা যায় না")
            return
        }
        val existing = bookmarks.indexOfFirst { it.url == t.url }
        if (existing >= 0) {
            bookmarks.removeAt(existing)
            toast("বুকমার্ক সরানো হয়েছে")
        } else {
            bookmarks.add(Entry(t.title.ifBlank { t.url }, t.url))
            toast("বুকমার্ক করা হয়েছে")
        }
        writeList("bookmarks", bookmarks)
        updateUi()
    }

    private fun addHistory(title: String, url: String) {
        if (isStart(url) || url.startsWith("data:")) return
        history.removeAll { it.url == url }
        history.add(0, Entry(title, url))
        while (history.size > 200) history.removeAt(history.size - 1)
        writeList("history", history)
    }

    private fun showBookmarks() {
        showList("বুকমার্ক (চেপে ধরলে মুছে যাবে)", bookmarks, "কোনো বুকমার্ক নেই", { current?.web?.loadUrl(it.url) }) { i ->
            bookmarks.removeAt(i)
            writeList("bookmarks", bookmarks)
            updateUi()
            toast("বুকমার্ক মুছে ফেলা হয়েছে")
        }
    }

    private fun showHistory() {
        showList("ইতিহাস", history, "এখনও কোনো পেজ দেখা হয়নি", { current?.web?.loadUrl(it.url) }, null)
    }

    private fun showList(
        title: String,
        items: List<Entry>,
        emptyMsg: String,
        onPick: (Entry) -> Unit,
        onLong: ((Int) -> Unit)?
    ) {
        if (items.isEmpty()) {
            toast(emptyMsg)
            return
        }
        val list = ListView(this)
        val labels = items.map { (if (it.title.isBlank()) it.url else it.title) + "\n" + it.url }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(list)
            .setNegativeButton("বন্ধ", null)
            .create()
        list.setOnItemClickListener { _, _, i, _ ->
            dialog.dismiss()
            onPick(items[i])
        }
        if (onLong != null) {
            list.setOnItemLongClickListener { _, _, i, _ ->
                dialog.dismiss()
                onLong(i)
                true
            }
        }
        dialog.show()
    }

    private fun readList(key: String): MutableList<Entry> {
        val out = mutableListOf<Entry>()
        try {
            val arr = JSONArray(prefs.getString(key, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.optString("t"), o.optString("u")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun writeList(key: String, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url)) }
        prefs.edit().putString(key, arr.toString()).apply()
    }
}
